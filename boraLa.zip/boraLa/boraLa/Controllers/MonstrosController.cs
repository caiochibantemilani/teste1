﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using Microsoft.AspNetCore.Mvc;

namespace SeuProjeto.Controllers
{
    public class MonstrosController : Controller
    {
        public ActionResult Index()
        {
            string connectionString = "Data Source=CAIO;Initial Catalog=master;Persist Security Info=True;User ID=caio;Password=Ioneer0#;";
            List<Monstro> monstros = new List<Monstro>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // Consulta SQL
                    string sqlQuery = "SELECT * FROM Monstros";

                    using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            // Verificar se existem registros retornados
                            if (reader.HasRows)
                            {
                                // Ler e exibir os dados retornados
                                while (reader.Read())
                                {
                                    Monstro monstro = new Monstro
                                    {
                                        Cod = reader.GetInt32(0),
                                        Nome = reader.GetString(1),
                                        Historia = reader.GetString(2),
                                        OndeVive = reader.GetString(3),
                                        ComoAtaca = reader.GetString(4)
                                    };

                                    monstros.Add(monstro);
                                }
                            }
                        }
                    }

                    connection.Close();
                }
                catch (Exception ex)
                {
                    ViewBag.ErrorMessage = "Erro ao conectar ao banco de dados: " + ex.Message;
                }
            }

            return View(monstros);
        }
    }

    public class Monstro
    {
        public int Cod { get; set; }
        public string Nome { get; set; }
        public string Historia { get; set; }
        public string OndeVive { get; set; }
        public string ComoAtaca { get; set; }
    }
}
